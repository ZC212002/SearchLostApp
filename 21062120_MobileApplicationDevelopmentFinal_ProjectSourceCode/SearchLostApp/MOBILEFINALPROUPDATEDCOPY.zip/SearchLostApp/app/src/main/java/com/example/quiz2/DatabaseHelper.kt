import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "tasks.db"
        private const val DATABASE_VERSION = 5
        const val TABLE_NAME = "tasks"
        const val COLUMN_TASK_ID = "task_id"
        const val COLUMN_TASK_TITLE = "task_title"
        const val COLUMN_TASK_NAME = "task_name"
        const val COLUMN_TASK_PHOTO_URL = "task_photo_url"
        const val COLUMN_TASK_DATE_TIME = "task_date_time"// New column for task photo URL
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableQuery = ("CREATE TABLE $TABLE_NAME (" +
                "$COLUMN_TASK_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COLUMN_TASK_TITLE TEXT NOT NULL, " +
                "$COLUMN_TASK_NAME TEXT NOT NULL, " +
                "$COLUMN_TASK_PHOTO_URL TEXT" +
                "$COLUMN_TASK_DATE_TIME TEXT" +// Add the new column for task photo URL
                ")")
        db.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            // If the old version is 1, perform the necessary upgrade to version 2
            val alterTableQuery = ("ALTER TABLE $TABLE_NAME " +
                    "ADD COLUMN $COLUMN_TASK_TITLE TEXT NOT NULL DEFAULT ''")
            db.execSQL(alterTableQuery)
        }

        if (oldVersion < 3) {
            // If the old version is 1 or 2, perform the necessary upgrade to version 3
            // Add any other database changes for version 3 here
            // For example:
            // db.execSQL("ALTER TABLE $TABLE_NAME ADD COLUMN new_column INTEGER DEFAULT 0")
        }

        if (oldVersion < 4) {
            // If the old version is 1, 2 or 3, perform the necessary upgrade to version 4
            // Add the new column for task photo URL
            val alterTableQuery = ("ALTER TABLE $TABLE_NAME " +
                    "ADD COLUMN $COLUMN_TASK_PHOTO_URL TEXT")
            db.execSQL(alterTableQuery)
        }

        if (oldVersion < 5){
            val alterTableQuery = ("ALTER TABLE $TABLE_NAME " +
                    "ADD COLUMN $COLUMN_TASK_DATE_TIME TEXT")
            db.execSQL(alterTableQuery)
        }
    }

    fun insertImageURL(taskId: Int, imageURL: String) {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_TASK_PHOTO_URL, imageURL)
        db.update(TABLE_NAME, values, "$COLUMN_TASK_ID=?", arrayOf(taskId.toString()))
        db.close()

    }
    fun insertTask(taskTitle: String, taskName: String, taskDateTime: String?, taskPhotoUrl: String?): Long {
        val db = this.writableDatabase
        val values = ContentValues()
        values.put(COLUMN_TASK_TITLE, taskTitle)
        values.put(COLUMN_TASK_NAME, taskName)
        taskDateTime?.let { values.put(COLUMN_TASK_DATE_TIME, it) }
        taskPhotoUrl?.let { values.put(COLUMN_TASK_PHOTO_URL, it) }

        return db.insert(TABLE_NAME, null, values)
    }

    fun updateTask(taskId: Int, taskTitle: String, taskName: String, taskDateTime: String?, taskPhotoUrl: String?) {
        val db = this.writableDatabase

        val values = ContentValues()
        values.put(COLUMN_TASK_TITLE, taskTitle)
        values.put(COLUMN_TASK_NAME, taskName)
        taskDateTime?.let { values.put(COLUMN_TASK_DATE_TIME, it) }
        taskPhotoUrl?.let { values.put(COLUMN_TASK_PHOTO_URL, it) }

        db.update(TABLE_NAME, values, "$COLUMN_TASK_ID=?", arrayOf(taskId.toString()))
        db.close()
    }

    fun getTask(taskId: Int): Task? {
        val db = this.readableDatabase
        val cursor = db.query(
            TABLE_NAME,
            null,
            "$COLUMN_TASK_ID=?",
            arrayOf(taskId.toString()),
            null,
            null,
            null
        )

        var task: Task? = null

        if (cursor.moveToFirst()) {
            val taskTitle = cursor.getString(cursor.getColumnIndex(COLUMN_TASK_TITLE))
            val taskName = cursor.getString(cursor.getColumnIndex(COLUMN_TASK_NAME))
            val taskPhotoUrl = cursor.getString(cursor.getColumnIndex(COLUMN_TASK_PHOTO_URL))
            val taskDateTime = cursor.getString(cursor.getColumnIndex(COLUMN_TASK_DATE_TIME))


            task = Task(taskId, taskTitle, taskName, taskPhotoUrl, taskDateTime)
        }

        cursor.close()
        return task
    }
}
