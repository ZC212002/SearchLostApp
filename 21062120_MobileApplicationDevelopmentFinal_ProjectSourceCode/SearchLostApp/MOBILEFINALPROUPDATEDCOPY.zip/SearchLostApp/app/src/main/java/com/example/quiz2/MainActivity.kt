package com.example.quiz2

import DatabaseHelper
import Task
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), SearchView.OnQueryTextListener {
    private lateinit var taskList: ArrayList<Task>
    private lateinit var adapter: TaskAdapter
    private lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Add database copying here (assuming it's handled by the "DatabaseCopyHelper")

        toolbarMainActivity.title = "Searching For Lost Person"
        toolbarMainActivity.subtitle = "Happiness lie in rendering help to others!"
        setSupportActionBar(toolbarMainActivity)

        recyclerView.setHasFixedSize(true)
        recyclerView.layoutManager = LinearLayoutManager(this@MainActivity)

        db = DatabaseHelper(this@MainActivity)

        getAllTasks()

        fab.setOnClickListener {
            startActivity(Intent(this@MainActivity, TaskRegistrationActivity::class.java))
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.search_menu, menu)

        val item = menu.findItem(R.id.action_search)
        val searchView = item.actionView as SearchView
        searchView.setOnQueryTextListener(this)

        return super.onCreateOptionsMenu(menu)
    }

    override fun onBackPressed() {
        val intent = Intent(Intent.ACTION_MAIN)
        intent.addCategory(Intent.CATEGORY_HOME)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
    }

    override fun onQueryTextSubmit(query: String): Boolean {
        Log.e("Submitted search query", query)
        performSearch(query)
        return true
    }

    override fun onQueryTextChange(newText: String): Boolean {
        Log.e("Search query change", newText)
        performSearch(newText)
        return true
    }

    fun getAllTasks() {
        taskList = TaskDAO().getAllTasks(db)
        adapter = TaskAdapter(this@MainActivity, taskList, db)
        recyclerView.adapter = adapter
    }

    fun performSearch(searchKeyword: String) {
        taskList = TaskDAO().searchTasks(db, searchKeyword)
        adapter = TaskAdapter(this@MainActivity, taskList, db)
        recyclerView.adapter = adapter
    }
}
