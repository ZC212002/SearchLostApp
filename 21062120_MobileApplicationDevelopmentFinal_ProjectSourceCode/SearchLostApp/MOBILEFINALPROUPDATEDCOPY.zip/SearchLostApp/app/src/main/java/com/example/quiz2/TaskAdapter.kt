package com.example.quiz2

import DatabaseHelper
import Task
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView

class TaskAdapter(var mContext: Context, var taskList: ArrayList<Task>, var db: DatabaseHelper)
    : RecyclerView.Adapter<TaskAdapter.CardViewHolder>() {

    inner class CardViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var cardView: CardView
        var textView: TextView
        var imageView: ImageView

        init {
            cardView = view.findViewById(R.id.cardView)
            textView = view.findViewById(R.id.textViewTaskName)
            imageView = view.findViewById(R.id.imageViewDelete)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardViewHolder {
        val view = LayoutInflater.from(mContext).inflate(R.layout.task_row_layout, parent, false)
        return CardViewHolder(view)
    }

    override fun getItemCount(): Int {
        return taskList.size
    }

    override fun onBindViewHolder(holder: CardViewHolder, position: Int) {
        val task = taskList[position]

        holder.textView.text = "${task.taskTitle}"

        holder.imageView.setOnClickListener {
            Toast.makeText(mContext, "${task.taskTitle} has been found. Thank you for giving a helping hand", Toast.LENGTH_SHORT).show()

            TaskDAO().deleteTask(db, task.taskId)

            taskList = TaskDAO().getAllTasks(db)
            notifyDataSetChanged()
        }

        holder.cardView.setOnClickListener {
            val intent = Intent(mContext, TaskDetailActivity::class.java)
            intent.putExtra("task", task)
            mContext.startActivity(intent)
        }
    }
}